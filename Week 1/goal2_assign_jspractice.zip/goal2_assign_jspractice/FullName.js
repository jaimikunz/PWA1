function calcLetters(){

var firstName = lastName;
var firstName = 5 letters;
var lastName = 4 letters;
var fullName = [firstName + lastName = fullName];
var fullName = [firstName + 5 letters + lastName + 4 letters];

console.log ("calcLetters");
};
