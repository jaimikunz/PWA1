function

if(sunny){goPlayatTheBeach();
} else{
	if(warmWater){wearNewSuit();
} else{

 (goToThePark();
}

console.log("goPlayatTheBeach!")