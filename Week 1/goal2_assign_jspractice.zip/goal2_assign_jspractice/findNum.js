var num1 = 15;
var num2 = 10;
num1 += num2;
console.log ("+=: ", num1);



var myStr = "10" + 6;
console.log ("Number + Strings: ", myStr);




var num = 2 + (5 * 5 - 8) / 5;
console.log ("order of operations: ", num);



