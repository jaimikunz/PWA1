function calcArea(){
	var width = 30;
	var height =50;
	var area = width * height;
	console.log(area);

}
calcArea();
