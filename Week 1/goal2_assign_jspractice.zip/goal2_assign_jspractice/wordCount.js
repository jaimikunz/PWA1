var kidHeight = 37;
var minHeight = 45;
if(kidHeight > minHeight){
	console.log("you can ride the hayride to the apple orchard!");

}else{
console.log("Sorry, you need to ride with your parents!");
}
