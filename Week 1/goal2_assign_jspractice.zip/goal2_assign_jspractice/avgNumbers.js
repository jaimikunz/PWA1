

function calcArea(){
	var width = 10;
	var height = 20;
	var volume = 10;
	var area = width * height * volume;
	console.log(area);
}
calcArea();
