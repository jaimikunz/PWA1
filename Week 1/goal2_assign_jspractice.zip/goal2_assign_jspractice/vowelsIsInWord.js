var gpa = 3.2;
if( gpa > 1.5){
	console.log ("you can graduate!");
}else{
	console.log ("gpa is to low!")
}

( gpa > 1.5) ? console.log("You can Graduate!") : console.log("GPA Too Low!")