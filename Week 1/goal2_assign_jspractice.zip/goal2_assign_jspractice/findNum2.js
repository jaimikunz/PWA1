var arr1 = [1,2,3,4,5,6,7,8,9];
var arr2 =['a','b','c','d','e','f'];
var arr3 = ['apple','bananana', 5672, 5.327];

console.log(arr2.indexOf('e'));



console.log(arr2.join(','));
